﻿using UstaPlatform.Domain.Entities;
using UstaPlatform.Domain.Enums;
using UstaPlatform.Domain.Interfaces;
using UstaPlatform.Infrastructure.Repositories;
using UstaPlatform.Pricing;
using System.Globalization;

// Kültür ayarını Türkçe (TL) için yapalım
CultureInfo.CurrentCulture = new CultureInfo("tr-TR");

Console.WriteLine("=================================");
Console.WriteLine("UstaPlatform v1.0 Başlatılıyor...");
Console.WriteLine("=================================");

// --- 1. Proje Kurulumu (DI/Bağımlılıkların Hazırlanması) ---
// DIP: Somut sınıflara değil, arayüzlere bağımlıyız.
IWorkOrderRepository repository = new InMemoryWorkOrderRepository();
Cizelge cizelge = new Cizelge(repository);

// Nesne Başlatıcılar (Object Initializers) kullanarak test verisi oluşturalım
var ustalar = new List<Usta>
{
    new Usta { Id = 1, AdSoyad = "Ahmet Yılmaz", Alan = UzmanlikAlani.Tesisatci, MusaitMi = true, Puan = 4.5 },
    new Usta { Id = 2, AdSoyad = "Ayşe Kaya", Alan = UzmanlikAlani.Elektrikci, MusaitMi = true, Puan = 4.9 }
};

var vatandas = new Vatandas { Id = 101, AdSoyad = "Mehmet Öztürk", Konum = (10, 15) };
Console.WriteLine("Test verisi (Usta, Vatandaş) oluşturuldu.");


// --- 2. Fiyat Motorunu Başlat (PLUGIN MİMARİSİ BURADA DEVREYE GİRİYOR) ---
// Motor, oluşturulurken (constructor'da) "Plugins" klasörünü tarar.
Console.WriteLine("\n--- Fiyat Motoru Başlatılıyor ---");
PricingEngine fiyatMotoru = new PricingEngine();
Console.WriteLine("--- Fiyat Motoru Hazır ---\n");


// --- 3. Senaryo: Hafta İçi Talep ---
Console.WriteLine("########################################");
Console.WriteLine("### SENARYO 1: HAFTA İÇİ TALEP ###");
Console.WriteLine("########################################");

// init-only özellikler (Id, KayitZamani) ve nesne başlatıcılar kullanılıyor
var talep1 = new Talep
{
    Id = 1, // Id'yi 'init' olduğu için burada atıyoruz
    VatandasId = vatandas.Id,
    IsTanimi = "Mutfak musluğu sızdırıyor",
    GerekliUzmanlik = UzmanlikAlani.Tesisatci,
    Konum = vatandas.Konum,
    IstenenTarih = new DateOnly(2025, 10, 24) // Cuma
};

// Basit eşleştirme (ilk uygun ustayı bul)
var usta1 = ustalar.First(u => u.Alan == talep1.GerekliUzmanlik && cizelge.IsUstaMusait(u.Id, talep1.IstenenTarih));

var isEmri1 = new IsEmri
{
    // Id = 1, // Repository'de otomatik artacak şekilde düzelttik
    TalepId = talep1.Id,
    UstaId = usta1.Id,
    Tarih = talep1.IstenenTarih,
    TemelUcret = 200m, // Temel ücret
    Konum = talep1.Konum
};

// Fiyatı hesapla ve kaydet
fiyatMotoru.CalculatePrice(isEmri1);
repository.Add(isEmri1);
Console.WriteLine($"Senaryo 1 Tamamlandı. İş Emri #{isEmri1.Id}, Tutar: {isEmri1.NihaiUcret:C}\n");


// --- 4. Senaryo: Hafta Sonu Talep (Dahili Kural Testi) ---
Console.WriteLine("############################################################");
Console.WriteLine("### SENARYO 2: HAFTA SONU TALEP (HaftasonuEkUcretiKurali) ###");
Console.WriteLine("############################################################");
var talep2 = new Talep
{
    Id = 2,
    VatandasId = vatandas.Id,
    IsTanimi = "Sigorta attı",
    GerekliUzmanlik = UzmanlikAlani.Elektrikci,
    Konum = (12, 18),
    IstenenTarih = new DateOnly(2025, 10, 25) // Cumartesi
};

var usta2 = ustalar.First(u => u.Alan == talep2.GerekliUzmanlik && cizelge.IsUstaMusait(u.Id, talep2.IstenenTarih));

var isEmri2 = new IsEmri
{
    // Id = 2,
    TalepId = talep2.Id,
    UstaId = usta2.Id,
    Tarih = talep2.IstenenTarih,
    TemelUcret = 300m,
    Konum = talep2.Konum
};

// Fiyatı hesapla (Hafta sonu kuralı çalışmalı + varsa harici kurallar)
fiyatMotoru.CalculatePrice(isEmri2);
repository.Add(isEmri2);
Console.WriteLine($"Senaryo 2 Tamamlandı. İş Emri #{isEmri2.Id}, Tutar: {isEmri2.NihaiUcret:C}\n");


// --- 5. Diğer C# Özelliklerinin Demosu ---

// Rota (Özel IEnumerable ve Koleksiyon Başlatıcı)
Console.WriteLine("--- Rota (IEnumerable<T> ve Koleksiyon Başlatıcı) Demosu ---");
// Koleksiyon başlatıcı kullanılıyor
var ustaRotasi = new Rota
{
    { isEmri1.Konum.X, isEmri1.Konum.Y }, // Rota.Add(int X, int Y) metodunu çağırır
    { isEmri2.Konum.X, isEmri2.Konum.Y }
};

Console.WriteLine($"Usta {usta1.AdSoyad} Rotası:");
foreach (var durak in ustaRotasi)
{
    Console.WriteLine($"- Durak: ({durak.X}, {durak.Y})");
}

// Çizelge (Dizinleyici / Indexer)
Console.WriteLine("\n--- Çizelge (Indexer) Demosu ---");
DateOnly cumartesi = new DateOnly(2025, 10, 25);
Console.WriteLine($"{cumartesi} Tarihli İşler (cizelge[cumartesi]):");

// Indexer kullanılıyor
foreach (var isEmri in cizelge[cumartesi])
{
    Console.WriteLine($"- İş Emri #{isEmri.Id}, Usta ID: {isEmri.UstaId}, Tutar: {isEmri.NihaiUcret:C}");
}

Console.WriteLine("\n=================================");
Console.WriteLine("Demo Sonu. ");
Console.WriteLine("ŞİMDİ: 'LoyaltyDiscountRule.dll' dosyasını 'Plugins' klasörüne kopyalayın ve programı YENİDEN ÇALIŞTIRIN.");
Console.WriteLine($"Plugins Klasör Yolu: {Path.Combine(AppContext.BaseDirectory, "Plugins")}");
Console.WriteLine("Programı kapatmak için bir tuşa basın...");
Console.ReadLine();