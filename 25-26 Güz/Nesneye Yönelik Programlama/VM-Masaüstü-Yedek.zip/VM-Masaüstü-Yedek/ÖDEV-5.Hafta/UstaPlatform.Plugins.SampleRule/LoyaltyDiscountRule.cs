﻿// UstaPlatform.Plugins.SampleRule/LoyaltyDiscountRule.cs
using UstaPlatform.Domain;

namespace LoyaltyDiscountRule
{
    public class LoyaltyDiscountRule : IPricingRule
    {
        public string Name => "LoyaltyDiscountRule";
        // Basit: ustanın puanı 4.5 üzeriyse %10 indirim
        public decimal Apply(decimal currentPrice, Talep talep, Usta chosenUsta)
        {
            if (chosenUsta.Puan >= 4.5) return currentPrice * 0.9m;
            return currentPrice;
        }
    }
}