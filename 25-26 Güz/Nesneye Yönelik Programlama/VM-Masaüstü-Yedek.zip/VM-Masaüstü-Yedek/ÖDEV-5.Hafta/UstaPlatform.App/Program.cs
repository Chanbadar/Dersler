﻿// UstaPlatform.App/Program.cs
using System;
using System.IO;
using UstaPlatform.Domain;
using UstaPlatform.Infrastructure;
using UstaPlatform.Pricing;

class Program
{
    static void Main()
    {
        Console.WriteLine("UstaPlatform Demo");

        // Örnek ustalar
        var ustalar = new List<Usta>
        {
            new Usta{ Id = 1, Ad = "Ali Usta", Uzmanlik = "Tesisat", Puan = 4.7 },
            new Usta{ Id = 2, Ad = "Mehmet Usta", Uzmanlik = "Elektrik", Puan = 4.2 }
        };

        var uRepo = new InMemoryUstaRepository(ustalar);
        var woRepo = new InMemoryWorkOrderRepository();
        var schedule = new Schedule();

        // Pricing engine ve plugin klasörü
        var engine = new PricingEngine();
        var pluginsFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Plugins");
        Console.WriteLine($"Loading plugins from {pluginsFolder}");
        engine.LoadRulesFromFolder(pluginsFolder);

        // Ayrıca built-in rule ekle
        engine.Rules.ToList().ForEach(r => Console.WriteLine($"Loaded rule: {r.Name}"));

        // Örnek talep
        var talep = new Talep
        {
            Id = 1,
            CitizenId = 1,
            Aciklama = "Musluk sızıntısı",
            IstenenTarih = DateOnly.FromDateTime(DateTime.Today.AddDays(1)),
            TemelUcret = 500m
        };

        // Basit eşleştirme: en az yoğunluklu usta
        var chosen = uRepo.GetAll().OrderBy(u => u.Yogunluk).First();

        // Fiyat hesapla
        var finalPrice = engine.CalculatePrice(talep, chosen);
        Console.WriteLine($"Final price for Talep {talep.Id} with {chosen.Ad}: {MoneyFormatter.Format(finalPrice)}");

        // WorkOrder oluştur & schedule ekle
        var wo = new WorkOrder { Id = 1, TalepId = talep.Id, UstaId = chosen.Id, Baslangic = DateTime.Today.AddDays(1).AddHours(9), Bitis = DateTime.Today.AddDays(1).AddHours(11), Fiyat = finalPrice };
        woRepo.Add(wo);
        schedule.Add(wo);

        Console.WriteLine($"WorkOrder created and scheduled on {wo.Baslangic}. Schedule entries for {DateOnly.FromDateTime(wo.Baslangic)}: {schedule[DateOnly.FromDateTime(wo.Baslangic)].Count}");
        Console.WriteLine("Demo complete.");
    }
}