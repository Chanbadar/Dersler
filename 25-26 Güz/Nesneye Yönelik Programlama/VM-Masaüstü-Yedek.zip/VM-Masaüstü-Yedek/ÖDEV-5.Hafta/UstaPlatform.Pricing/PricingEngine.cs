﻿// UstaPlatform.Pricing/PricingEngine.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UstaPlatform.Domain;

namespace UstaPlatform.Pricing
{
    public class PricingEngine
    {
        private readonly List<IPricingRule> _rules = new();

        public IReadOnlyList<IPricingRule> Rules => _rules.AsReadOnly();

        // Klasörden tüm DLL'leri tarar ve IPricingRule implementer'larını yükler
        public void LoadRulesFromFolder(string folderPath)
        {
            if (!Directory.Exists(folderPath)) Directory.CreateDirectory(folderPath);

            var dlls = Directory.GetFiles(folderPath, "*.dll", SearchOption.TopDirectoryOnly);
            foreach (var dll in dlls)
            {
                try
                {
                    var asm = Assembly.LoadFrom(dll);
                    var types = asm.GetTypes()
                        .Where(t => typeof(IPricingRule).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract);
                    foreach (var t in types)
                    {
                        try
                        {
                            var rule = (IPricingRule?)Activator.CreateInstance(t);
                            if (rule != null && !_rules.Any(r => r.GetType() == rule.GetType()))
                                _rules.Add(rule);
                        }
                        catch (Exception ex) { Console.WriteLine($"Rule load error: {ex.Message}"); }
                    }
                }
                catch (Exception ex) { Console.WriteLine($"Assembly load error ({dll}): {ex.Message}"); }
            }
        }

        // Kompozisyon: kurallar sırayla uygulanır
        public decimal CalculatePrice(Talep talep, Usta usta)
        {
            decimal price = talep.TemelUcret;
            foreach (var rule in _rules)
            {
                price = rule.Apply(price, talep, usta);
            }
            return price;
        }
    }

    // Örnek yerel kural (app içinde de olabilir)
    public class HaftasonuEkUcretiRule : IPricingRule
    {
        public string Name => "HaftaSonuEkUcreti";
        public decimal Apply(decimal currentPrice, Talep talep, Usta chosenUsta)
        {
            var dow = talep.IstenenTarih.DayOfWeek;
            if (dow == DayOfWeek.Saturday || dow == DayOfWeek.Sunday)
            {
                return currentPrice + currentPrice * 0.25m; // +%25
            }
            return currentPrice;
        }
    }
}
