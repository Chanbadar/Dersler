﻿// UstaPlatform.Infrastructure/InMemoryRepositories.cs
using System.Collections.Concurrent;
using System.Collections.Generic;
using UstaPlatform.Domain;

namespace UstaPlatform.Infrastructure
{
    public class InMemoryWorkOrderRepository : IWorkOrderRepository
    {
        private readonly ConcurrentBag<WorkOrder> _bag = new();
        public void Add(WorkOrder wo) => _bag.Add(wo);
        public IEnumerable<WorkOrder> GetByUsta(int ustaId) => _bag.Where(w => w.UstaId == ustaId);
    }

    public class InMemoryUstaRepository : IUstaRepository
    {
        private readonly List<Usta> _list = new();
        public InMemoryUstaRepository(IEnumerable<Usta> initial) => _list.AddRange(initial);
        public IEnumerable<Usta> GetAll() => _list;
        public Usta? GetById(int id) => _list.FirstOrDefault(u => u.Id == id);
    }
}

