﻿// UstaPlatform.Infrastructure/Helpers.cs
using System;
using System.Collections.Concurrent;
using UstaPlatform.Domain;

namespace UstaPlatform.Infrastructure
{
    public static class Guard
    {
        public static void NotNull(object? obj, string name)
        {
            if (obj is null) throw new ArgumentNullException(name);
        }
    }

    public static class MoneyFormatter
    {
        public static string Format(decimal amount) => $"{amount:0.00} ₺";
    }

    public static class GeoHelper
    {
        public static double Distance((int X, int Y) a, (int X, int Y) b)
        {
            var dx = a.X - b.X; var dy = a.Y - b.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}

