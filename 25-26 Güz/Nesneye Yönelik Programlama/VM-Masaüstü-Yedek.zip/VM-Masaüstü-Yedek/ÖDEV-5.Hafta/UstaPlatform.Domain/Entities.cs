﻿// UstaPlatform.Domain/Entities.cs
using System;
using System.Collections.Generic;

namespace UstaPlatform.Domain
{
    public record Usta
    {
        public int Id { get; init; }                // init-only
        public string Ad { get; init; } = null!;
        public string Uzmanlik { get; init; } = null!;
        public double Puan { get; init; }
        public int Yogunluk { get; set; } // güncel çalışma yükü, değişebilir
    }

    public record Citizen
    {
        public int Id { get; init; }
        public string Ad { get; init; } = null!;
        public string Adres { get; init; } = null!;
    }

    public record Talep
    {
        public int Id { get; init; }
        public int CitizenId { get; init; }
        public string Aciklama { get; init; } = null!;
        public DateOnly IstenenTarih { get; init; }
        public (int X, int Y)? Konum { get; init; }
        public decimal TemelUcret { get; init; }
    }

    public record WorkOrder
    {
        public int Id { get; init; }
        public int TalepId { get; init; }
        public int UstaId { get; init; }
        public DateTime Baslangic { get; set; }
        public DateTime Bitis { get; set; }
        public decimal Fiyat { get; set; }
        public (int X, int Y)? DurakKonumu { get; set; }
    }

    // Pricing rule interface for plugins
    public interface IPricingRule
    {
        string Name { get; }
        decimal Apply(decimal currentPrice, Talep talep, Usta chosenUsta);
    }

    // Repository interfaces (DIP)
    public interface IWorkOrderRepository
    {
        void Add(WorkOrder wo);
        IEnumerable<WorkOrder> GetByUsta(int ustaId);
    }

    public interface IUstaRepository
    {
        IEnumerable<Usta> GetAll();
        Usta? GetById(int id);
    }
}
