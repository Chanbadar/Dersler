﻿// UstaPlatform.Domain/Collections.cs
using System;
using System.Collections;
using System.Collections.Generic;

namespace UstaPlatform.Domain
{
    // Route implements IEnumerable<(int X,int Y)> and supports collection initializer
    public class Route : IEnumerable<(int X, int Y)>
    {
        private readonly List<(int X, int Y)> _points = new();

        public void Add(int X, int Y) => _points.Add((X, Y)); // supports collection initializers
        public IEnumerator<(int X, int Y)> GetEnumerator() => _points.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    // Schedule with indexer by DateOnly
    public class Schedule
    {
        private readonly Dictionary<DateOnly, List<WorkOrder>> _byDate = new();

        public List<WorkOrder> this[DateOnly date]
        {
            get
            {
                if (!_byDate.TryGetValue(date, out var list))
                {
                    list = new List<WorkOrder>();
                    _byDate[date] = list;
                }
                return list;
            }
        }

        public void Add(WorkOrder wo)
        {
            var date = DateOnly.FromDateTime(wo.Baslangic);
            this[date].Add(wo);
        }
    }
}
