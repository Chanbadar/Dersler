# Hafta 7 — Etkinlik Kayıt ve Bildirim Uygulaması

Üç konteyner: Python kayıt REST hizmeti, Python bildirim tüketicisi/sonuç API'si,
RabbitMQ mesaj aracısı. Kubernetes gerekmez. Gerçek e-posta gönderilmez.
Bildirim etkisi, ayrı SQLite dosyasında oluşturulan sonuç kaydıdır.
Python sözdizimini öğrenmek hedef değildir; kodlar kısa ve açıklamalıdır.

## Hızlı başlangıç

Docker Desktop çalışıyor ve Linux containers seçili olmalıdır. ZIP'i açın;
compose.yaml bulunan Hafta7_Uygulama klasöründe terminal/PowerShell açın:

```powershell
docker compose up --build -d
docker compose ps
docker compose logs --tail 50 kayit bildirim
```

İlk çalıştırmada internet bağlantısıyla Python ve RabbitMQ imajları indirilir.
Makineye ayrıca Python, RabbitMQ veya SQLite kurulmaz.

Adresler:
- http://localhost:8080/etkinlikler — kayıt API'si
- http://localhost:8081/sonuclar — tamamlanan bildirimler
- http://localhost:15672 — RabbitMQ arayüzü; kullanıcı ders, parola hafta7-yerel

Bu eğitim parolası yalnız localhost'a bağlı yerel kurulum içindir.
RabbitMQ'nun AMQP portu hosta yayımlanmaz; konteyner ağı içinden kullanılır.
Başlangıç etkinlikleri: 42 (5 kişi), 43 (2 kişi), 44 (kayıt kapalı).

## İlk kayıt

```powershell
$body = @{etkinlikId=42; katilimciId=108} | ConvertTo-Json
$r = Invoke-RestMethod -Uri http://localhost:8080/kayitlar -Method Post -ContentType 'application/json' -Body $body
$r
Invoke-RestMethod -Uri ("http://localhost:8080/kayitlar/" + $r.kayitId)
Invoke-RestMethod -Uri http://localhost:8081/sonuclar
```

Aynı katılımcıyla tekrar kayıt 409 döndürür; yeni kayıtlar için başka katilimciId kullanın.
PowerShell 409 gibi yanıtları hata olarak gösterir; bu deneyde beklenen sonuçtur.
Alternatif: ornekler/istekler.http (isteğe bağlı VS Code REST Client) veya Postman.
`curl` kullanacaksanız Windows PowerShell'de `curl.exe` yazın.

## Temel deneyler

1. Geçerli/hatalı istekleri ornekler/istekler.http üzerinden karşılaştırın.
2. `docker compose stop bildirim` çalıştırın; yeni kayıt oluşturun.
   Kayıt tamamlanır. /outbox mesajın aracılık sistemine aktarımını gösterir.
   RabbitMQ arayüzünde hafta7.bildirim kuyruğunda bekleyen işleri görün.
3. `docker compose start bildirim`; sonuçları ve logları inceleyin.
4. Aşağıdaki tekrar komutunda gerçek kayitId kullanın. İşçi çalışırken sonuçtaki
   teslimSayisi artar, aynı isId için sonuç satırı sayısı 1 kalır.

```powershell
Invoke-RestMethod -Uri ("http://localhost:8080/kayitlar/" + $r.kayitId + "/bildirimi-tekrarla") -Method Post
```

5. `docker compose down`, sonra `docker compose up -d`; önceki sonuçlar korunur.
   Kalıcı veriyi koruma deneyinde `down -v` KULLANMAYIN.
6. kayit/store.py içindeki KATILIMCI_ID_UST_SINIRI değerini değiştirin.
   `docker compose up --build -d kayit`; sınırın iki tarafındaki kimlikleri deneyin.

## Ek deneyler

Gerçek onay kaybı:
```powershell
Invoke-RestMethod -Uri http://localhost:8081/deneyler/onay-oncesi-kapanma -Method Post
```
Ardından daha önce kullanılmamış kimlikle yeni kayıt oluşturun. Sonuç commit edilir,
ancak işçi onaydan önce bir kez kapanır. Compose yeniden başlatır; RabbitMQ onaysız
mesajı tekrar teslim eder. Loglarda SONUC_OLUSTURULDU ve TEKRAR_TANINDI görülebilir.
Tek seferlik işaret kalıcı olarak temizlenir; sonsuz kapanma döngüsü oluşmaz.

Geçersiz mesaj / başarısız kuyruk:
```powershell
docker compose exec kayit python scripts/gecersiz_mesaj.py
```
RabbitMQ arayüzünde hafta7.basarisiz kuyruğunu inceleyin. Hatalı mesajlar otomatik
düzeltilmez. Bu deney temel teslim çalışmasına ek, isteğe bağlıdır.

## Otomatik kontroller

Gerçek REST + RabbitMQ + tüketici akışı (çalışan Compose gerektirir):
```powershell
docker compose exec kayit python scripts/smoke_test.py
```
Test bir yeni kayıt tüketir; kontenjan doluysa durur. Verileri kendiliğinden silmez.

Birim ve HTTP sözleşme testleri (broker gerekmez; hostta Python 3.12):
```powershell
python -m unittest discover -s tests -v
```
Docker içinde aynı testler için kaynak klasörünü geçici bağlayın:
```powershell
docker compose run --rm --no-deps -v "${PWD}:/test" -w /test kayit python -m unittest discover -s tests -v
```

## Kalıcılık ve doğruluk

- kayıt verisi ve gönderilecek iş AYNI SQLite transaction içinde yazılır.
- Outbox aktarım görevi, yayıncı onayından sonra satırı iletildi olarak işaretler.
- Onay ve outbox işareti arasındaki kapanmada tekrar yayın mümkündür.
- Bildirim sonucu, isId birincil anahtarıyla ve transaction içinde yazılır.
- Mesaj, ancak sonuç commit edildikten sonra onaylanır.
- İki ayrı SQLite dosyası ve iki ayrı named volume kullanılır; hizmetler diğerinin
  dosyasına erişmez. SQLite tek makinedeki eğitim için seçilmiştir.
- /health uçtan uca çalışmayı değil HTTP sürecini gösterir; broker koparsa outbox bekler.

Bu düzen üretim ölçekli/yüksek erişilebilirlikli sistem değildir: tek RabbitMQ düğümü,
SQLite, kimlik doğrulamasız localhost deney uç noktaları içerir. Gerçek dış e-posta
ve ödeme yan etkileri için sonuç kaydından daha kapsamlı tekrar önleme gerekir.
FaaS bulut dağıtımı bu yerel paketin parçası değildir; ayrı bulut yönergesinde ele alınır.

## Dosyalar

kayit/: REST API, kayıt kuralları, outbox aktarımı.
bildirim/: tüketici, idempotent sonuç deposu, gözlem API'si.
ortak/: bağlantı/HTTP yardımcıları; iş verisi paylaşımı değildir.
ornekler/: HTTP istekleri ve PowerShell örneği.
scripts/: gerçek sistem doğrulaması ve başarısız mesaj deneyi.
tests/: kayıt yarışı, atomik kayıt, tekrarlar, kalıcılık ve HTTP sözleşme testleri.
API_SOZLESMESI.md: uç noktalar ve beklenen yanıtlar.
DOGRULAMA.md: bu paketin hazırlanırken yapılan kontrolleri ve sınırları.

## Sorun giderme

- 8080/8081/15672 doluysa compose.yaml sol taraftaki host portunu değiştirin;
  örnek isteklerdeki localhost portunu da güncelleyin.
- Mesaj aracısının sağlıklı olmasını bekleyin: docker compose ps / logs mesaj-aracisi.
- Sonuç yoksa /outbox ve docker compose logs bildirim çıktısını inceleyin.
- DB hatası varsa SQLite volume izinlerini ve tek makinede çalışmayı kontrol edin.
- Yeni şema/queue değişikliklerinde eski veriler farklı olabilir; bu pakette varsayılan
  başlangıç için kendi proje adı hafta7 kullanılır.

Verileri tamamen sıfırlamak yalnız deney kayıtlarına ihtiyaç kalmadığında:
`docker compose down -v` kayıtları, sonuçları VE kuyruk verisini kalıcı olarak siler.
Bu işlem otomatik testlere eklenmemiştir.

Kaynaklar: https://www.rabbitmq.com/tutorials/tutorial-two-python
https://pika.readthedocs.io/ ve https://docs.docker.com/compose/how-tos/startup-order/
