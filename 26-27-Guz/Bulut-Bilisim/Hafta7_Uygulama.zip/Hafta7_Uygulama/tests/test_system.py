import json
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from kayit.store import Store as RegistrationStore
from kayit.app import make_handler
from bildirim.store import Store as NotificationStore, InvalidJob
from ortak.http import ApiError
from ortak.db import connect

class SystemTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.k=RegistrationStore(str(Path(self.tmp.name)/'kayit.sqlite'));self.k.init()
        self.b=NotificationStore(str(Path(self.tmp.name)/'bildirim.sqlite'));self.b.init()
    def tearDown(self):self.tmp.cleanup()
    def register(self,p=108,e=42): return self.k.create({'etkinlikId':e,'katilimciId':p})
    def assert_error(self,code,fn):
        with self.assertRaises(ApiError) as ctx:fn()
        self.assertEqual(ctx.exception.status,code)
    def test_registration_and_job_are_saved_together(self):
        r=self.register();job=json.loads(self.k.pending()[0]['body'])
        self.assertEqual(job['kayitId'],r['kayitId'])
        self.assertEqual(job['isId'],r['bildirimIsId'])
    def test_outbox_insert_failure_rolls_back_registration(self):
        with connect(self.k.path) as db:
            db.execute("CREATE TRIGGER reject_outbox BEFORE INSERT ON outbox BEGIN SELECT RAISE(ABORT,'test'); END")
        with self.assertRaises(Exception): self.register()
        self.assertEqual(self.k.events(42)['bosKontenjan'],5)
    def test_validation_rejects_bool_and_string(self):
        for v in [True,False,'108',0,-1,1.5,None]:
            self.assert_error(400,lambda:self.k.create({'etkinlikId':42,'katilimciId':v}))
    def test_missing_event(self):self.assert_error(404,lambda:self.register(e=999))
    def test_closed_event(self):self.assert_error(409,lambda:self.register(e=44))
    def test_duplicate_registration_does_not_consume_capacity(self):
        self.register();self.assert_error(409,self.register)
        self.assertEqual(self.k.events(42)['bosKontenjan'],4)
        self.assertEqual(len(self.k.pending()),1)
    def test_concurrent_capacity(self):
        def attempt(p):
            try:self.register(p,e=43);return 201
            except ApiError as e:return e.status
        with ThreadPoolExecutor(max_workers=8) as pool: codes=list(pool.map(attempt,range(1,13)))
        self.assertEqual(codes.count(201),2)
        self.assertEqual(codes.count(409),10)
    def test_concurrent_duplicate(self):
        def attempt(_):
            try:self.register();return 201
            except ApiError as e:return e.status
        with ThreadPoolExecutor(max_workers=5) as pool:codes=list(pool.map(attempt,range(8)))
        self.assertEqual(codes.count(201),1)
    def test_relay_failure_preserves_pending_job(self):
        self.register();row=self.k.pending()[0];self.k.failed(row['id'],'connection lost')
        self.assertEqual(len(self.k.pending()),1)
        self.assertEqual(self.k.outbox()[0]['denemeSayisi'],1)
        self.k.sent(row['id']);self.assertEqual(self.k.pending(),[])
    def test_repeat_preserves_job_identity(self):
        r=self.register();self.k.sent(self.k.pending()[0]['id']);self.k.repeat(r['kayitId'])
        self.assertEqual(json.loads(self.k.pending()[0]['body'])['isId'],r['bildirimIsId'])
    def test_same_job_has_one_result(self):
        self.register();job=json.loads(self.k.pending()[0]['body'])
        self.assertEqual(self.b.process(job),(True,False))
        self.assertEqual(self.b.process(job),(False,False))
        self.assertEqual(len(self.b.results()),1)
        self.assertEqual(self.b.results()[0]['teslimSayisi'],2)
    def test_concurrent_redelivery_has_one_effect(self):
        self.register();job=json.loads(self.k.pending()[0]['body'])
        with ThreadPoolExecutor(max_workers=8) as pool:vals=list(pool.map(lambda _:self.b.process(job)[0],range(12)))
        self.assertEqual(sum(vals),1)
        self.assertEqual(self.b.results()[0]['teslimSayisi'],12)
    def test_changed_payload_for_same_id_rejected(self):
        self.register();job=json.loads(self.k.pending()[0]['body']);self.b.process(job)
        job['katilimciId']=109
        with self.assertRaises(InvalidJob):self.b.process(job)
        self.assertEqual(len(self.b.results()),1)
    def test_invalid_notification_rejected(self):
        with self.assertRaises(InvalidJob):self.b.process({'isId':'a'})
    def test_persistence_on_store_recreation(self):
        r=self.register();job=json.loads(self.k.pending()[0]['body']);self.b.process(job)
        k=RegistrationStore(self.k.path);k.init();b=NotificationStore(self.b.path);b.init()
        self.assertEqual(k.registration(r['kayitId'])['durum'],'onaylandi')
        self.assertEqual(len(b.results()),1)
        self.assertEqual(len(k.pending()),1)
    def test_crash_marker_once_and_after_commit(self):
        self.b.arm_crash();self.register();job=json.loads(self.k.pending()[0]['body'])
        self.assertEqual(self.b.process(job),(True,True))
        b=NotificationStore(self.b.path);b.init()
        self.assertEqual(b.process(job),(False,False))
        self.register(109);nextjob=json.loads(self.k.pending()[1]['body'])
        self.assertEqual(b.process(nextjob),(True,False))
    def test_http_contract(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.k))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_port}'
        def call(path,data=None):
            req=Request(base+path,data=json.dumps(data).encode() if data is not None else None,
                        headers={'Content-Type':'application/json'})
            try:r=urlopen(req,timeout=3)
            except HTTPError as e:r=e
            return r.status,dict(r.headers),json.load(r)
        try:
            code,headers,r=call('/kayitlar',{'etkinlikId':42,'katilimciId':108})
            self.assertEqual(code,201);self.assertEqual(headers['Location'],f"/kayitlar/{r['kayitId']}")
            self.assertEqual(call(headers['Location'])[0],200)
            self.assertEqual(call('/kayitlar',{'etkinlikId':42,'katilimciId':108})[0],409)
            self.assertEqual(call('/kayitlar',{'etkinlikId':42})[0],400)
            self.assertEqual(call('/kayitlar/999')[0],404)
            self.assertEqual(call(f"/kayitlar/{r['kayitId']}/bildirimi-tekrarla",{})[0],202)
        finally:server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main(verbosity=2)
