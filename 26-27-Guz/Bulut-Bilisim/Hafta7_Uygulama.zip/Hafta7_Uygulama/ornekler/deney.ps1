# PowerShell 5.1 ve PowerShell 7. Yeni kayıtta verilen değer kullanılmamış olmalıdır.
param([int]$KatilimciId=108, [int]$EtkinlikId=42)
$ErrorActionPreference='Stop'
$body=@{etkinlikId=$EtkinlikId;katilimciId=$KatilimciId}|ConvertTo-Json
$r=Invoke-RestMethod -Uri 'http://localhost:8080/kayitlar' -Method Post -ContentType 'application/json' -Body $body
$r|ConvertTo-Json
Write-Host ('KayitId: '+$r.kayitId+' / IsId: '+$r.bildirimIsId)
Write-Host 'Sonucu inceleyin: http://localhost:8081/sonuclar'
