"""Gerçek Compose sistemi üzerinde kayıt, tüketim ve tekrar teslim kontrolü.
Çalıştırma: docker compose exec kayit python scripts/smoke_test.py
"""
import json
import os
import time
from urllib.request import Request,urlopen
from urllib.error import HTTPError
K=os.getenv('API_BASE','http://kayit:8080')
B=os.getenv('RESULT_BASE','http://bildirim:8081')

def call(base,path,data=None):
    req=Request(base+path,data=json.dumps(data).encode() if data is not None else None,
                headers={'Content-Type':'application/json'})
    try:
        with urlopen(req,timeout=5) as r:return r.status,json.load(r)
    except HTTPError as e:return e.code,json.load(e)

def wait_result(job,count=1):
    deadline=time.monotonic()+45
    while time.monotonic()<deadline:
        status,data=call(B,'/sonuclar/'+job)
        if status==200 and data['teslimSayisi']>=count:return data
        time.sleep(1)
    raise RuntimeError('45 saniyede sonuç gelmedi; compose logs ve /outbox çıktısını inceleyin.')

def main():
    status,events=call(K,'/etkinlikler');assert status==200
    e=next((e for e in events if e['kayitAcik'] and e['bosKontenjan']>0),None)
    if not e:raise RuntimeError('Örnek etkinliklerde boş kontenjan yok. Yeni ve boş veriyle test edin; bu araç veri silmez.')
    participant=int(time.time_ns()%800000)+100000
    status,r=call(K,'/kayitlar',{'etkinlikId':e['etkinlikId'],'katilimciId':participant})
    assert status==201,(status,r)
    rid,job=r['kayitId'],r['bildirimIsId']
    result=wait_result(job)
    status,dup=call(K,'/kayitlar',{'etkinlikId':e['etkinlikId'],'katilimciId':participant})
    assert status==409 and dup['kod']=='MEVCUT_KAYIT'
    assert call(K,'/kayitlar',{'etkinlikId':e['etkinlikId']})[0]==400
    before=result['teslimSayisi']
    assert call(K,f'/kayitlar/{rid}/bildirimi-tekrarla',{})[0]==202
    after=wait_result(job,before+1)
    assert after['tamamlanmaZamani']==result['tamamlanmaZamani']
    status,all_results=call(B,'/sonuclar');assert status==200
    assert sum(v['isId']==job for v in all_results)==1
    print(json.dumps({'sonuc':'BASARILI','kayitId':rid,'isId':job,
                      'teslimSayisi':after['teslimSayisi'],'tekSonuc':True},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
