"""İsteğe bağlı DLQ deneyi; docker compose exec kayit python scripts/gecersiz_mesaj.py"""
import json
from ortak.broker import open_channel,publish
c,ch=open_channel()
try:
    publish(ch,json.dumps({'isId':'gecersiz-deney','kayitId':-1}),'gecersiz-deney')
    print('Geçersiz mesaj iletildi. Bildirim logunu ve hafta7.basarisiz kuyruğunu inceleyin.')
finally:c.close()
