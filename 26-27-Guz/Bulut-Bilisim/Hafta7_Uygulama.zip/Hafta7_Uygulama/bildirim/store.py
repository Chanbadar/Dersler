'''Gönderim taklidi: iş etkisi bu hizmetin SQLite sonuç kaydıdır; gerçek e-posta yok.'''
import hashlib
import json
from ortak.db import connect, now
from ortak.http import ApiError

class InvalidJob(ValueError): pass

def validate(data):
    if not isinstance(data,dict): raise InvalidJob('JSON nesnesi gerekli.')
    if not isinstance(data.get('isId'),str) or not data['isId'] or len(data['isId'])>100:
        raise InvalidJob('Geçerli isId gerekli.')
    for key in ['kayitId','etkinlikId','katilimciId']:
        if type(data.get(key)) is not int or data[key]<=0: raise InvalidJob(f'{key} geçersiz.')
    if data.get('isTuru')!='KayitBildirimi': raise InvalidJob('isTuru geçersiz.')
    return {key:data[key] for key in ['isId','kayitId','etkinlikId','katilimciId','isTuru']}

class Store:
    def __init__(self,path): self.path=path

    def init(self):
        with connect(self.path) as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
            CREATE TABLE IF NOT EXISTS results(
                job_id TEXT PRIMARY KEY, registration_id INTEGER NOT NULL,
                payload_hash TEXT NOT NULL, message TEXT NOT NULL,
                processed_at TEXT NOT NULL, deliveries INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS controls(key TEXT PRIMARY KEY,value INTEGER NOT NULL);
            INSERT OR IGNORE INTO controls VALUES('crash_once',0);
            ''')

    def process(self,data):
        data=validate(data)
        digest=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
        with connect(self.path) as db:
            db.execute('BEGIN IMMEDIATE')
            old=db.execute('SELECT * FROM results WHERE job_id=?',(data['isId'],)).fetchone()
            if old:
                if old['payload_hash']!=digest:
                    raise InvalidJob('Aynı iş kimliği farklı içerikle kullanılamaz.')
                db.execute('UPDATE results SET deliveries=deliveries+1 WHERE job_id=?',(data['isId'],))
                return False,False
            db.execute('INSERT INTO results VALUES(?,?,?,?,?,1)',(data['isId'],data['kayitId'],digest,
                f"Katılımcı {data['katilimciId']}: etkinlik {data['etkinlikId']} kaydınız alındı.",now()))
            crash=db.execute("SELECT value FROM controls WHERE key='crash_once'").fetchone()[0]==1
            if crash: db.execute("UPDATE controls SET value=0 WHERE key='crash_once'")
            # Sonuç ve tek seferlik deney işareti birlikte commit edilir.
        return True,crash

    def arm_crash(self):
        with connect(self.path) as db: db.execute("UPDATE controls SET value=1 WHERE key='crash_once'")

    def results(self,job=None):
        with connect(self.path) as db:
            rows=db.execute('SELECT * FROM results WHERE (? IS NULL OR job_id=?) ORDER BY processed_at',(job,job)).fetchall()
        out=[{'isId':r['job_id'],'kayitId':r['registration_id'],'durum':'tamamlandi',
              'mesaj':r['message'],'tamamlanmaZamani':r['processed_at'],
              'teslimSayisi':r['deliveries']} for r in rows]
        if job is not None:
            if not out: raise ApiError(404,'SONUC_YOK','Sonuç henüz yok; bu yanıt kayıt başarısız demek değildir.')
            return out[0]
        return out
