import json
import logging
import os
import sqlite3
import threading
import time
from http.server import ThreadingHTTPServer
from urllib.parse import urlparse
from ortak.http import Handler, ApiError
from bildirim.store import Store, InvalidJob

log=logging.getLogger(__name__)

def consume(store):
    from ortak.broker import open_channel, publish, QUEUE
    while True:
        connection=None
        try:
            connection,channel=open_channel()
            channel.basic_qos(prefetch_count=1)
            def callback(ch,method,properties,body):
                try:
                    data=json.loads(body)
                    delay=float(os.getenv('ISLEM_GECIKMESI','1'))
                    connection.sleep(max(0,min(delay,10)))
                    created,crash=store.process(data)
                    log.info('%s isId=%s redelivered=%s',
                        'SONUC_OLUSTURULDU' if created else 'TEKRAR_TANINDI',data['isId'],method.redelivered)
                    if crash:
                        log.warning('DENEY: sonuç commit edildi; onaydan önce süreç kapanıyor.')
                        os._exit(77)
                    # Ancak kalıcı sonuç tamamlandığında onayla.
                    ch.basic_ack(delivery_tag=method.delivery_tag)
                except (ValueError,UnicodeError,InvalidJob) as e:
                    log.error('Geçersiz iş başarısız kuyruğuna: %s',e)
                    ch.basic_nack(delivery_tag=method.delivery_tag,requeue=False)
                except sqlite3.Error as e:
                    headers=dict(properties.headers or {})
                    attempt=int(headers.get('retry',0))+1
                    if attempt<=int(os.getenv('MAX_RETRY','3')):
                        connection.sleep(2)
                        headers['retry']=attempt
                        # Yeniden yayının onayı alınmadan eski teslim silinmez.
                        publish(ch,body,properties.message_id or '',headers)
                        ch.basic_ack(delivery_tag=method.delivery_tag)
                        log.warning('Depo hatası, tekrar %s: %s',attempt,e)
                    else:
                        ch.basic_nack(delivery_tag=method.delivery_tag,requeue=False)
                        log.error('Yeniden deneme sınırı aşıldı: %s',e)
                # Bağlantı hatası dış döngüye çıkar; onaysız mesaj yeniden teslim edilebilir.
            channel.basic_consume(queue=QUEUE,on_message_callback=callback,auto_ack=False)
            log.info('Bildirim tüketicisi hazır')
            channel.start_consuming()
        except Exception as e:
            log.warning('Tüketici bağlantısı yeniden kurulacak: %s',e)
            time.sleep(3)
        finally:
            if connection and connection.is_open: connection.close()

def make_handler(store):
    class API(Handler):
        def route(self,method):
            path=urlparse(self.path).path.rstrip('/') or '/'
            if method=='GET' and path=='/health':return 200,{'durum':'calisiyor'},None
            if method=='GET' and path=='/sonuclar':return 200,store.results(),None
            if method=='GET' and path.startswith('/sonuclar/'):
                return 200,store.results(path.split('/')[-1]),None
            if method=='POST' and path=='/deneyler/onay-oncesi-kapanma':
                store.arm_crash()
                return 200,{'durum':'hazir','mesaj':'Sonraki YENİ işte sonuç commit edildikten sonra süreç bir kez kapanır. Compose yeniden başlatır.'},None
            raise ApiError(404,'UC_NOKTA_YOK','Uç nokta bulunamadı.')
    return API

def main():
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    store=Store(os.getenv('DB_PATH','/data/bildirim.sqlite'));store.init()
    threading.Thread(target=consume,args=(store,),daemon=True).start()
    ThreadingHTTPServer(('0.0.0.0',int(os.getenv('PORT','8081'))),make_handler(store)).serve_forever()

if __name__=='__main__':main()
