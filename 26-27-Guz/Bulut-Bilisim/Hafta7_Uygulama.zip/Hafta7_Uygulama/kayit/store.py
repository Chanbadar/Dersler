import json
from uuid import uuid4
from ortak.db import connect, now
from ortak.http import ApiError

# Öğrenci değişikliği örneği: bu sınırı değiştirip geçerli/hatalı istekleri karşılaştırın.
KATILIMCI_ID_UST_SINIRI = 999999

def positive_int(data, name):
    v = data.get(name)
    if type(v) is not int or v <= 0:
        raise ApiError(400, 'GECERSIZ_ALAN', f'{name} pozitif tam sayı olmalıdır.')
    return v

class Store:
    def __init__(self, path): self.path = path

    def init(self):
        with connect(self.path) as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY, name TEXT NOT NULL, capacity INTEGER NOT NULL,
                is_open INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS registrations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL,
                participant_id INTEGER NOT NULL, job_id TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                UNIQUE(event_id, participant_id), FOREIGN KEY(event_id) REFERENCES events(id));
            CREATE TABLE IF NOT EXISTS outbox(
                id INTEGER PRIMARY KEY AUTOINCREMENT, job_id TEXT NOT NULL,
                body TEXT NOT NULL, sent_at TEXT, attempts INTEGER NOT NULL DEFAULT 0,
                last_error TEXT, created_at TEXT NOT NULL);
            ''')
            db.executemany('INSERT OR IGNORE INTO events VALUES(?,?,?,?)', [
                (42,'Bulut Bilişim Atölyesi',5,1),
                (43,'Mikroservis Semineri',2,1),
                (44,'Kayıtları Kapanmış Etkinlik',5,0)])

    def events(self, event_id=None):
        with connect(self.path) as db:
            rows = db.execute('''SELECT e.*, (SELECT count(*) FROM registrations r
                WHERE r.event_id=e.id) AS used FROM events e
                WHERE (? IS NULL OR e.id=?) ORDER BY e.id''', (event_id,event_id)).fetchall()
        out = [{'etkinlikId':r['id'],'ad':r['name'],'kontenjan':r['capacity'],
                'bosKontenjan':r['capacity']-r['used'],'kayitAcik':bool(r['is_open'])} for r in rows]
        if event_id is not None:
            if not out: raise ApiError(404,'ETKINLIK_YOK','Etkinlik bulunamadı.')
            return out[0]
        return out

    def message(self, r):
        return {'isId':r['job_id'],'kayitId':r['id'],'etkinlikId':r['event_id'],
                'katilimciId':r['participant_id'],'isTuru':'KayitBildirimi'}

    def registration(self, registration_id):
        with connect(self.path) as db:
            r = db.execute('SELECT * FROM registrations WHERE id=?',(registration_id,)).fetchone()
            if r is None: raise ApiError(404,'KAYIT_YOK','Kayıt bulunamadı.')
            pending = db.execute('SELECT count(*) FROM outbox WHERE job_id=? AND sent_at IS NULL',
                                 (r['job_id'],)).fetchone()[0]
        return {'kayitId':r['id'],'etkinlikId':r['event_id'],'katilimciId':r['participant_id'],
                'durum':'onaylandi','bildirimIsId':r['job_id'],
                'aktarimDurumu':'bekliyor' if pending else 'araciya_iletildi',
                'olusturmaZamani':r['created_at']}

    def create(self, data):
        event = positive_int(data,'etkinlikId')
        participant = positive_int(data,'katilimciId')
        if participant > KATILIMCI_ID_UST_SINIRI:
            raise ApiError(400,'KATILIMCI_SINIRI','Katılımcı kimliği izin verilen sınırı aşıyor.')
        with connect(self.path) as db:
            # Yazıcı kilidi: kontenjan kontrolü ve kayıt oluşturma birlikte korunur.
            db.execute('BEGIN IMMEDIATE')
            e = db.execute('SELECT * FROM events WHERE id=?',(event,)).fetchone()
            if e is None: raise ApiError(404,'ETKINLIK_YOK','Etkinlik bulunamadı.')
            if not e['is_open']: raise ApiError(409,'KAYIT_KAPALI','Etkinlik kayıt kabul etmiyor.')
            if db.execute('SELECT 1 FROM registrations WHERE event_id=? AND participant_id=?',
                          (event,participant)).fetchone():
                raise ApiError(409,'MEVCUT_KAYIT','Katılımcı bu etkinliğe zaten kayıtlı.')
            count = db.execute('SELECT count(*) FROM registrations WHERE event_id=?',(event,)).fetchone()[0]
            if count >= e['capacity']: raise ApiError(409,'KONTENJAN_DOLU','Boş kontenjan yok.')
            job = 'is-'+uuid4().hex
            created = now()
            cursor = db.execute('INSERT INTO registrations(event_id,participant_id,job_id,created_at) VALUES(?,?,?,?)',
                                (event,participant,job,created))
            rid = cursor.lastrowid
            body = json.dumps({'isId':job,'kayitId':rid,'etkinlikId':event,
                               'katilimciId':participant,'isTuru':'KayitBildirimi'},ensure_ascii=False)
            # Aynı transaction: kayıt varsa iletilecek iş de vardır.
            db.execute('INSERT INTO outbox(job_id,body,created_at) VALUES(?,?,?)',(job,body,created))
        return self.registration(rid)

    def repeat(self, rid):
        with connect(self.path) as db:
            r=db.execute('SELECT * FROM registrations WHERE id=?',(rid,)).fetchone()
            if r is None: raise ApiError(404,'KAYIT_YOK','Kayıt bulunamadı.')
            db.execute('INSERT INTO outbox(job_id,body,created_at) VALUES(?,?,?)',
                       (r['job_id'],json.dumps(self.message(r),ensure_ascii=False),now()))
        return {'isId':r['job_id'],'durum':'tekrar_aktarim_bekliyor'}

    def pending(self):
        with connect(self.path) as db:
            return [dict(r) for r in db.execute('SELECT * FROM outbox WHERE sent_at IS NULL ORDER BY id LIMIT 20')]

    def sent(self, oid):
        with connect(self.path) as db:
            db.execute('UPDATE outbox SET sent_at=?, attempts=attempts+1,last_error=NULL WHERE id=?',(now(),oid))

    def failed(self, oid, error):
        with connect(self.path) as db:
            db.execute('UPDATE outbox SET attempts=attempts+1,last_error=? WHERE id=?',(str(error)[:300],oid))

    def outbox(self):
        with connect(self.path) as db:
            return [dict(r) for r in db.execute('SELECT id,job_id AS isId,sent_at AS iletilmeZamani,attempts AS denemeSayisi,last_error AS sonHata FROM outbox ORDER BY id')]
