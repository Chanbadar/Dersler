'''REST sunucusu ve tek outbox aktarım iş parçacığı.'''
import logging
import os
import threading
import time
from http.server import ThreadingHTTPServer
from urllib.parse import urlparse
from ortak.http import Handler, ApiError
from kayit.store import Store

log = logging.getLogger(__name__)

def relay(store):
    from ortak.broker import open_channel, publish
    while True:
        connection = None
        try:
            connection, channel = open_channel()
            log.info('Mesaj aracısına bağlanıldı')
            while True:
                for row in store.pending():
                    try:
                        publish(channel,row['body'],row['job_id'])
                        store.sent(row['id'])
                        log.info('İş iletildi: %s',row['job_id'])
                    except Exception as e:
                        store.failed(row['id'],e)
                        raise
                connection.sleep(1)
        except Exception as e:
            log.warning('Aktarım bekliyor; bağlantı tekrar denenecek: %s',e)
            time.sleep(3)
        finally:
            if connection and connection.is_open:
                connection.close()

def make_handler(store):
    class API(Handler):
        def route(self, method):
            path = urlparse(self.path).path.rstrip('/') or '/'
            parts=path.strip('/').split('/')
            if method=='GET' and path=='/health': return 200, {'durum':'calisiyor'},None
            if method=='GET' and path=='/etkinlikler': return 200,store.events(),None
            if method=='GET' and len(parts)==2 and parts[0]=='etkinlikler' and parts[1].isdigit():
                return 200,store.events(int(parts[1])),None
            if method=='POST' and path=='/kayitlar':
                r=store.create(self.json_body());return 201,r,f"/kayitlar/{r['kayitId']}"
            if method=='GET' and len(parts)==2 and parts[0]=='kayitlar' and parts[1].isdigit():
                return 200,store.registration(int(parts[1])),None
            # Yerel deney uç noktası: yeni iş değil, aynı iş tekrar teslim edilir.
            if method=='POST' and len(parts)==3 and parts[0]=='kayitlar' and parts[1].isdigit() and parts[2]=='bildirimi-tekrarla':
                return 202,store.repeat(int(parts[1])),None
            if method=='GET' and path=='/outbox': return 200,store.outbox(),None
            raise ApiError(404,'UC_NOKTA_YOK','Uç nokta bulunamadı.')
    return API

def main():
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    store=Store(os.getenv('DB_PATH','/data/kayit.sqlite'));store.init()
    threading.Thread(target=relay,args=(store,),daemon=True).start()
    ThreadingHTTPServer(('0.0.0.0',int(os.getenv('PORT','8080'))),make_handler(store)).serve_forever()

if __name__=='__main__': main()
