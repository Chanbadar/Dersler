# Doğrulama Durumu

Paket hazırlanırken Python 3.12 ortamında 17 birim/HTTP testi çalıştırılmış ve tamamı geçmiştir.

Kontrol edilen davranışlar:
- Kayıt ile outbox işinin aynı transaction içinde oluşturulması.
- Outbox yazma hatasında kaydın geri alınması.
- Eşzamanlı isteklerde kontenjanın aşılmaması ve tek katılımcı kaydı.
- Geçersiz, eksik, kapalı etkinlik ve tekrar kayıt yanıtları.
- Aynı işin eşzamanlı tekrarlarında tek sonuç oluşturulması.
- İş kimliğinin farklı içerikle kullanılmasının reddedilmesi.
- Depo nesneleri yeniden oluşturulduğunda verilerin ve bekleyen işlerin korunması.
- Sonuç commit edildikten sonraki tek seferlik kapanma işaretinin doğruluğu.
- Gerçek yerel HTTP sunucusunda 201/400/404/409/202 yanıtları ve Location başlığı.

Python kaynakları derlenmiş, Compose YAML yapısı ve üç ayrı veri hacmi kontrol edilmiştir.
Pika 1.3.2 bağımlılığı indirilip modüllerin yüklenmesi kontrol edilmiştir.

Sınır: Hazırlama ortamında Docker/Compose ve RabbitMQ çalışma ortamı bulunmadığı için
imaj oluşturma ve gerçek RabbitMQ ile uçtan uca çalışma BU ORTAMDA doğrulanmamıştır.
YAML ayrıştırma, `docker compose config` veya gerçek dağıtım testi yerine geçmez.

Docker Desktop ortamında kontrol sırası:
1. docker compose config
2. docker compose up --build -d
3. docker compose ps
4. docker compose exec kayit python scripts/smoke_test.py
5. README'deki tüketiciyi durdurma, yeniden teslim ve kalıcılık deneyleri.

smoke_test.py gerçek mesaj aracısını kullanır; simülasyon değildir ve başarısız
kontrolde sıfırdan farklı çıkış kodu verir. Yeni kayıt oluşturur; veri silmez.
Yerel paket FaaS bulut dağıtımını içermez. Bu çalışma ayrı yönergede ele alınır.
