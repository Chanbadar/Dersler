# Hafta 7 — Yerel API Sözleşmesi

Adresler: kayıt `http://localhost:8080`, sonuç `http://localhost:8081`.
Gövde JSON; kimlikler pozitif tam sayıdır (boolean ve sayı metni kabul edilmez).

| İşlem | Yanıt / açıklama |
|---|---|
| GET /etkinlikler | 200; etkinlik listesi, boş kontenjan |
| GET /etkinlikler/{id} | 200 veya 404 |
| POST /kayitlar | 201 + Location; etkinlikId, katilimciId zorunlu |
| GET /kayitlar/{id} | 200 veya 404; bildirimIsId ve aktarimDurumu |
| POST /kayitlar/{id}/bildirimi-tekrarla | 202; aynı isId yeni outbox satırıyla yeniden iletilir |
| GET /outbox | 200; mesaj aracısına aktarım denemeleri; bildirim tamamlanması DEĞİLDİR |
| GET /sonuclar | Bildirim hizmetinde 200; tamamlanan işler |
| GET /sonuclar/{isId} | 200 veya sonuç henüz yoksa 404 |
| POST /deneyler/onay-oncesi-kapanma | Bildirim hizmetinde yerel deney anahtarı |
| GET /health | HTTP süreci/sağlık kontrolü; uçtan uca mesaj akışı garantisi değildir |

400: eksik/geçersiz girdi; 404: etkinlik/kayıt/sonuç yok;
409: MEVCUT_KAYIT, KONTENJAN_DOLU veya KAYIT_KAPALI; 415: içerik türü uygun değil.

Örnek kayıt isteği: {"etkinlikId":42,"katilimciId":108}.
Kayıt yanıtı `durum=onaylandi` olabilirken bildirim hâlâ bekliyor olabilir.
Bildirim sonuç sorgusu kayıt hizmetinin veritabanını paylaşmaz.

Bildirim mesajı:
{"isId":"is-...","kayitId":1,"etkinlikId":42,"katilimciId":108,"isTuru":"KayitBildirimi"}

İş etkisi: bildirim sonuç deposunda isId başına tek satır.
Tekrar mesajlar teslimSayisi değerini artırır; başarılı sonuç ve tamamlanma zamanı korunur.
Aynı isId farklı içerikle gelirse başarısız mesaj kuyruğuna ayrılır.
Deney uç noktaları yerel eğitim içindir; kimlik doğrulama içermez, bulutta yayımlanmaz.
