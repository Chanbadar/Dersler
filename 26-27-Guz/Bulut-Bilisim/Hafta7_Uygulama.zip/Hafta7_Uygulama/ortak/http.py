'''Küçük, çerçeve bağımsız JSON HTTP yardımcıları. Yalnız yerel ders uygulaması.'''
import json
from http.server import BaseHTTPRequestHandler

class ApiError(Exception):
    def __init__(self, status, code, message):
        self.status, self.code, self.message = status, code, message

class Handler(BaseHTTPRequestHandler):
    def json_body(self):
        try:
            n = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            raise ApiError(400, 'GECERSIZ_ISTEK', 'Gövde uzunluğu geçersiz.')
        if n < 1 or n > 65536:
            raise ApiError(400, 'GECERSIZ_GOVDE', '1–65536 bayt arası JSON gövdesi gerekli.')
        if self.headers.get('Content-Type', '').split(';')[0].lower() != 'application/json':
            raise ApiError(415, 'ICERIK_TURU', 'Content-Type: application/json kullanın.')
        try:
            data = json.loads(self.rfile.read(n))
        except (ValueError, UnicodeError):
            raise ApiError(400, 'GECERSIZ_JSON', 'JSON çözümlenemedi.')
        if not isinstance(data, dict):
            raise ApiError(400, 'GECERSIZ_GOVDE', 'JSON nesnesi gerekli.')
        return data

    def send_json(self, status, data, location=None):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        if location:
            self.send_header('Location', location)
        self.end_headers()
        self.wfile.write(raw)

    def dispatch(self, method):
        try:
            status, data, location = self.route(method)
            self.send_json(status, data, location)
        except ApiError as e:
            self.send_json(e.status, {'kod': e.code, 'mesaj': e.message})
        except Exception:
            import logging
            logging.exception('HTTP işlem hatası')
            self.send_json(500, {'kod': 'SUNUCU_HATASI', 'mesaj': 'İşlem tamamlanamadı.'})

    def do_GET(self): self.dispatch('GET')
    def do_POST(self): self.dispatch('POST')
