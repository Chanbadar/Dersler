'''AMQP bağlantısı yalnız kendi iletişim iş parçacığında kullanılır.'''
import os
import pika

QUEUE = 'hafta7.bildirim'
DEAD_EXCHANGE = 'hafta7.dead'
DEAD_QUEUE = 'hafta7.basarisiz'

def open_channel():
    credentials = pika.PlainCredentials(os.getenv('BROKER_USER', 'ders'),
                                        os.getenv('BROKER_PASSWORD', 'hafta7-yerel'))
    parameters = pika.ConnectionParameters(
        host=os.getenv('BROKER_HOST', 'localhost'), port=int(os.getenv('BROKER_PORT','5672')),
        credentials=credentials, heartbeat=30, blocked_connection_timeout=10,
        socket_timeout=5, stack_timeout=10, connection_attempts=1)
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    channel.exchange_declare(exchange=DEAD_EXCHANGE, exchange_type='direct', durable=True)
    channel.queue_declare(queue=DEAD_QUEUE, durable=True)
    channel.queue_bind(queue=DEAD_QUEUE, exchange=DEAD_EXCHANGE, routing_key='failed')
    channel.queue_declare(queue=QUEUE, durable=True, arguments={
        'x-dead-letter-exchange': DEAD_EXCHANGE,
        'x-dead-letter-routing-key': 'failed'})
    channel.confirm_delivery()
    return connection, channel

def publish(channel, body, job_id='', headers=None):
    # Kalıcı mesaj + kalıcı kuyruk + yayıncı onayı; onaydan sonra outbox işaretlenir.
    channel.basic_publish(exchange='', routing_key=QUEUE, body=body,
        mandatory=True, properties=pika.BasicProperties(
            content_type='application/json', delivery_mode=2,
            message_id=job_id, headers=headers or {}))
